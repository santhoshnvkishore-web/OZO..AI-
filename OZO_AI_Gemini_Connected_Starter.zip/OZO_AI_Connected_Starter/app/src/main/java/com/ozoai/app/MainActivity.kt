package com.ozoai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.ArrowUpward
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.MoreHoriz
import androidx.compose.material.icons.outlined.Sparkles
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException

private val Ink = Color(0xFF090D18)
private val Panel = Color(0xFF121A2A)
private val Muted = Color(0xFF8E9AB0)
private val Cyan = Color(0xFF73D7F5)
private val White = Color(0xFFF4F7FC)

// Android Emulator -> development computer. For a deployed backend, use its HTTPS URL.
private const val BASE_URL = "http://10.0.2.2:8787/"
private val httpClient = OkHttpClient()

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OzoApp() }
    }
}

data class ChatMessage(val text: String, val fromUser: Boolean)

suspend fun askOzo(prompt: String): String = withContext(Dispatchers.IO) {
    val payload = JSONObject().put("message", prompt).toString()
    val body = payload.toRequestBody("application/json; charset=utf-8".toMediaType())
    val request = Request.Builder()
        .url("${BASE_URL}chat")
        .post(body)
        .build()

    httpClient.newCall(request).execute().use { response ->
        val responseText = response.body?.string().orEmpty()
        if (!response.isSuccessful) {
            val error = try { JSONObject(responseText).optString("error") } catch (_: Exception) { "" }
            throw IOException(if (error.isNotBlank()) error else "Server error (${response.code})")
        }
        JSONObject(responseText).optString("reply").ifBlank { "I couldn't create a reply. Please try again." }
    }
}

@Composable
fun OzoApp() {
    var input by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var messages by remember {
        mutableStateOf(listOf(ChatMessage("Hello! I'm OZO, your AI assistant. What would you like to explore today?", false)))
    }
    val scope = rememberCoroutineScope()

    MaterialTheme(colorScheme = darkColorScheme(
        background = Ink, surface = Panel, primary = Cyan,
        onBackground = White, onSurface = White
    )) {
        Column(
            modifier = Modifier.fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0xFF111B30), Ink)))
                .statusBarsPadding().navigationBarsPadding().padding(horizontal = 18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 22.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(42.dp).background(
                    Brush.linearGradient(listOf(Cyan, Color(0xFF6688FF))), CircleShape
                ), contentAlignment = Alignment.Center) {
                    Icon(Icons.Outlined.Sparkles, null, tint = Ink, modifier = Modifier.size(23.dp))
                }
                Spacer(Modifier.width(11.dp))
                Column(Modifier.weight(1f)) {
                    Text("OZO AI", color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    Text("Your intelligent companion", color = Muted, fontSize = 11.sp)
                }
                IconButton(onClick = { messages = emptyList(); error = null }) {
                    Icon(Icons.Outlined.Add, "New chat", tint = White)
                }
                IconButton(onClick = { }) {
                    Icon(Icons.Outlined.MoreHoriz, "More", tint = White)
                }
            }

            if (messages.size <= 1) {
                Spacer(Modifier.height(34.dp))
                Text("A little help,\na lot of possibilities.", color = White, fontSize = 31.sp,
                    lineHeight = 38.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(10.dp))
                Text("Ask anything. OZO is ready when you are.", color = Muted, fontSize = 14.sp)
                Spacer(Modifier.height(24.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    Suggestion("Explain a topic") { input = "Explain a topic simply" }
                    Suggestion("Write something") { input = "Help me write something" }
                }
                Spacer(Modifier.height(9.dp))
                Suggestion("Give me creative ideas") { input = "Give me creative ideas" }
            }

            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(vertical = 10.dp)
            ) {
                items(messages) { message ->
                    Row(Modifier.fillMaxWidth(),
                        horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start) {
                        Box(Modifier.widthIn(max = 300.dp).background(
                            if (message.fromUser) Color(0xFF203A54) else Panel,
                            RoundedCornerShape(18.dp)
                        ).padding(horizontal = 16.dp, vertical = 13.dp)) {
                            Text(message.text, color = White, fontSize = 14.sp, lineHeight = 21.sp)
                        }
                    }
                }
                if (loading) item {
                    Text("OZO is thinking…", color = Cyan, fontSize = 13.sp, modifier = Modifier.padding(8.dp))
                }
            }

            error?.let {
                Text(it, color = Color(0xFFFFA6A6), fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp))
            }

            Row(
                Modifier.fillMaxWidth().padding(bottom = 14.dp)
                    .background(Color(0xFF172236), RoundedCornerShape(25.dp))
                    .padding(start = 17.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BasicTextField(
                    value = input, onValueChange = { input = it },
                    modifier = Modifier.weight(1f).padding(vertical = 10.dp),
                    textStyle = androidx.compose.ui.text.TextStyle(color = White, fontSize = 14.sp),
                    singleLine = true,
                    decorationBox = { inner ->
                        if (input.isEmpty()) Text("Message OZO...", color = Muted, fontSize = 14.sp)
                        inner()
                    }
                )
                IconButton(onClick = { error = "Voice input will be added in a future version." }) {
                    Icon(Icons.Outlined.Mic, "Voice input", tint = Muted)
                }
                IconButton(
                    enabled = !loading,
                    onClick = {
                        val text = input.trim()
                        if (text.isNotEmpty()) {
                            messages = messages + ChatMessage(text, true)
                            input = ""
                            error = null
                            loading = true
                            scope.launch {
                                try {
                                    val reply = askOzo(text)
                                    messages = messages + ChatMessage(reply, false)
                                } catch (e: Exception) {
                                    error = e.message ?: "Couldn't reach OZO server."
                                } finally {
                                    loading = false
                                }
                            }
                        }
                    },
                    modifier = Modifier.size(42.dp).background(Cyan, CircleShape)
                ) {
                    Icon(Icons.Outlined.ArrowUpward, "Send", tint = Ink)
                }
            }
            Text("OZO can make mistakes. Check important information.",
                color = Muted.copy(alpha = 0.7f), fontSize = 10.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 8.dp))
        }
    }
}

@Composable
fun Suggestion(label: String, onClick: () -> Unit) {
    Surface(onClick = onClick, color = Color(0xFF172236), shape = RoundedCornerShape(20.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF293850))) {
        Text(label, color = Color(0xFFDCE8F7), fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp))
    }
}
