# OZO AI — Android + secure Gemini backend starter

This project contains:
- Android app (Kotlin + Jetpack Compose) with a simple premium chat UI.
- A small Node.js backend that keeps the Gemini API key on the server, not inside the APK.

## Important
This is a starter integration. It is not deployed or connected to a live Gemini account yet.
You must create your own Gemini API key and run the backend privately. Never send your API key in chat or commit it to source control.

## 1. Set up the backend
Requirements: Node.js 20+.

In `server/`:
```bash
npm install
```
Set the environment variable `GEMINI_API_KEY` on your computer/server. Do not put the key in Android source code.
Then run:
```bash
npm start
```
By default the backend listens on port 8787.

For local Android Emulator testing, the app's base URL is configured as:
`http://10.0.2.2:8787/`
This special address lets the Android emulator reach your development computer.
For a physical phone, use your computer's reachable LAN address on the same Wi-Fi, or deploy the backend with HTTPS and update `BASE_URL` in `MainActivity.kt`.

## 2. Build the Android APK
1. Open this folder in Android Studio.
2. Let Gradle sync; install Android SDK 35 if prompted.
3. Run the backend.
4. Run the app on an emulator, or build with **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## 3. API key setup
Create your own Gemini API key in Google AI Studio. Add it only as the `GEMINI_API_KEY` environment variable on the backend host. Do not paste it into this app or share it in a chat.

## Current scope
Text chat is wired to the backend. Voice input and image understanding are not included in this starter yet. The backend returns a clear error if no API key is configured.
