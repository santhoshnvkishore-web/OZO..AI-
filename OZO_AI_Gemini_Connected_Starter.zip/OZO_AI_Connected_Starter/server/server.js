import express from "express";
import { GoogleGenAI } from "@google/genai";

const app = express();
app.use(express.json({ limit: "1mb" }));

const PORT = process.env.PORT || 8787;
const API_KEY = process.env.GEMINI_API_KEY;

app.get("/health", (_req, res) => res.json({ ok: true, service: "OZO AI" }));

app.post("/chat", async (req, res) => {
  try {
    const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
    if (!message) return res.status(400).json({ error: "Please enter a message." });
    if (message.length > 8000) return res.status(413).json({ error: "Message is too long." });
    if (!API_KEY) return res.status(503).json({ error: "Backend setup is incomplete: GEMINI_API_KEY is not configured." });

    const ai = new GoogleGenAI({ apiKey: API_KEY });
    const result = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: message,
      config: {
        systemInstruction: "You are OZO AI, a helpful, clear, friendly assistant. Reply in the language the user uses, including Kannada or English."
      }
    });
    res.json({ reply: result.text || "I couldn't generate a response. Please try again." });
  } catch (err) {
    console.error("OZO request failed:", err?.message || err);
    res.status(500).json({ error: "OZO couldn't complete that request. Please try again." });
  }
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`OZO AI backend listening on port ${PORT}`);
});
